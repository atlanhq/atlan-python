from pyatlan.client.common import ApiCaller
from pyatlan.errors import ErrorCode
# SPDX-License-Identifier: Apache-2.0
# Copyright 2022 Atlan Pte. Ltd.
# Based on original code from https://github.com/apache/atlas (under Apache-2.0 license)
from __future__ import annotations

import abc
import contextlib
import copy
import json
import logging
import os
import time
import uuid
from abc import ABC
from types import SimpleNamespace
from typing import Any, ClassVar, Generator, Iterable, Optional, Type, TypeVar, Union
from warnings import warn

import requests
from pydantic import (
    BaseSettings,
    HttpUrl,
    PrivateAttr,
    StrictStr,
    ValidationError,
    constr,
    parse_obj_as,
    validate_arguments,
)
from requests.adapters import HTTPAdapter
from tenacity import retry, retry_if_exception_type, stop_after_attempt, wait_fixed
from urllib3.util.retry import Retry

from pyatlan.client.atlan import AtlanClient
from pyatlan.client.audit import AuditClient
from pyatlan.client.constants import (
    ADD_BUSINESS_ATTRIBUTE_BY_ID,
    ADD_USER_TO_GROUPS,
    ADMIN_EVENTS,
    BULK_UPDATE,
    CHANGE_USER_ROLE,
    CREATE_GROUP,
    CREATE_TYPE_DEFS,
    CREATE_USERS,
    DELETE_API_TOKEN,
    DELETE_ENTITIES_BY_GUIDS,
    DELETE_ENTITY_BY_ATTRIBUTE,
    DELETE_GROUP,
    DELETE_TYPE_DEF_BY_NAME,
    GET_ALL_TYPE_DEFS,
    GET_API_TOKENS,
    GET_CURRENT_USER,
    GET_ENTITY_BY_GUID,
    GET_ENTITY_BY_UNIQUE_ATTRIBUTE,
    GET_GROUP_MEMBERS,
    GET_GROUPS,
    GET_LINEAGE,
    GET_LINEAGE_LIST,
    GET_ROLES,
    GET_USER_GROUPS,
    GET_USERS,
    INDEX_SEARCH,
    KEYCLOAK_EVENTS,
    PARSE_QUERY,
    PARTIAL_UPDATE_ENTITY_BY_ATTRIBUTE,
    REMOVE_USERS_FROM_GROUP,
    UPDATE_ENTITY_BY_ATTRIBUTE,
    UPDATE_GROUP,
    UPDATE_TYPE_DEFS,
    UPDATE_USER,
    UPLOAD_IMAGE,
    UPSERT_API_TOKEN,
)
from pyatlan.client.user import UserClient
from pyatlan.client.workflow import WorkflowClient
from pyatlan.errors import ERROR_CODE_FOR_HTTP_STATUS, AtlanError, ErrorCode
from pyatlan.model.aggregation import Aggregations
from pyatlan.model.api_tokens import ApiToken, ApiTokenRequest, ApiTokenResponse
from pyatlan.model.assets import (
    Asset,
    AtlasGlossary,
    AtlasGlossaryCategory,
    AtlasGlossaryTerm,
    Connection,
    Database,
    MaterialisedView,
    Persona,
    Purpose,
    Referenceable,
    Schema,
    Table,
    View,
)
from pyatlan.model.atlan_image import AtlanImage
from pyatlan.model.core import (
    Announcement,
    AssetRequest,
    AssetResponse,
    AtlanObject,
    AtlanTag,
    AtlanTagName,
    AtlanTags,
    BulkRequest,
    SearchRequest,
)
from pyatlan.model.custom_metadata import CustomMetadataDict, CustomMetadataRequest
from pyatlan.model.enums import (
    AtlanConnectorType,
    AtlanDeleteType,
    AtlanTypeCategory,
    CertificateStatus,
    EntityStatus,
    LineageDirection,
)
from pyatlan.model.group import (
    AtlanGroup,
    CreateGroupRequest,
    CreateGroupResponse,
    GroupResponse,
    RemoveFromGroupRequest,
)
from pyatlan.model.lineage import LineageListRequest, LineageRequest, LineageResponse
from pyatlan.model.query import ParsedQuery, QueryParserRequest
from pyatlan.model.response import AssetMutationResponse
from pyatlan.model.role import RoleResponse
from pyatlan.model.search import (
    DSL,
    IndexSearchRequest,
    Query,
    Term,
    with_active_category,
    with_active_glossary,
    with_active_term,
)
from pyatlan.model.typedef import (
    AtlanTagDef,
    CustomMetadataDef,
    EnumDef,
    TypeDef,
    TypeDefResponse,
)
from pyatlan.model.user import (
    AddToGroupsRequest,
    AtlanUser,
    ChangeRoleRequest,
    CreateUserRequest,
    UserMinimalResponse,
    UserResponse,
)
from pyatlan.multipart_data_generator import MultipartDataGenerator
from pyatlan.utils import (
    API,
    HTTPStatus,
    get_logger,
    unflatten_custom_metadata_for_entity,
)

SERVICE_ACCOUNT_ = "service-account-"

class TokenClient:
    """
    This class can be used to retrieve information pertaining to tokens. This class does not need to be instantiated
    directly but can be obtained through the workflow property of AtlanClient.
    """

    def __init__(self, client: AtlanClient):
        if not isinstance(client, ApiCaller):
            raise ErrorCode.INVALID_PARAMETER_TYPE.exception_with_parameters(
                "client", "ApiCaller"
            )
        self._client = client
        
    def add_api_token_as_admin(
        self, asset_guid: str, impersonation_token: str
    ) -> Optional[AssetMutationResponse]:
        """
        Add the API token configured for the default client as an admin to the asset with the provided GUID.
        This is primarily useful for connections, to allow the API token to manage policies for the connection, and
        for query collections, to allow the API token to manage the queries in a collection or the collection itself.

        :param asset_guid: unique identifier (GUID) of the asset to which we should add this API token as an admin
        :param impersonation_token: a bearer token for an actual user who is already an admin for the asset,
                                    NOT an API token
        :raises NotFoundError: if the asset to which to add the API token as an admin cannot be found
        """
        from pyatlan.model.assets.asset00 import Asset
        from pyatlan.model.fluent_search import FluentSearch

        token_user = str(self._client.user.get_current().username)
        try:
            tmp = AtlanClient(base_url=self._client.base_url, api_key=impersonation_token)
            # Look for the asset as the impersonated user, ensuring we include the admin users
            # in the results (so we avoid clobbering any existing admin users)
            request = (
                FluentSearch()
                .where(Asset.GUID.eq(asset_guid))
                .include_on_results(Asset.ADMIN_USERS)
                .page_size(1)
            ).to_request()
            results = tmp.search(request)
            if results.current_page():
                asset = results.current_page()[0]
                existing_admins = asset.admin_users or set()
                existing_admins.add(token_user)
                to_update = asset.trim_to_required()
                to_update.admin_users = existing_admins
                response = tmp.save(to_update)
            else:
                raise ErrorCode.ASSET_NOT_FOUND_BY_GUID.exception_with_parameters(
                    asset_guid
                )
            return response
        except Exception:
            raise
        finally:
            AtlanClient.set_default_client(self._client)


    def add_api_token_as_viewer(
        self, asset_guid: str, impersonation_token: str
    ) -> Optional[AssetMutationResponse]:
        """
        Add the API token configured for the default client as a viewer to the asset with the provided GUID.
        This is primarily useful for query collections, to allow the API token to view or run queries within the
        collection, but not make any changes to them.

        :param asset_guid: unique identifier (GUID) of the asset to which we should add this API token as an admin
        :param impersonation_token: a bearer token for an actual user who is already an admin for the asset,
                                    NOT an API token
        :raises NotFoundError: if the asset to which to add the API token as a viewer cannot be found
        """
        from pyatlan.model.assets.asset00 import Asset
        from pyatlan.model.fluent_search import FluentSearch

        token_user = str(self.user.get_current().username)
        if existing_client := self.get_default_client():
            tmp = AtlanClient(base_url=self.base_url, api_key=impersonation_token)
            AtlanClient.set_default_client(tmp)
            # Look for the asset as the impersonated user, ensuring we include the admin users
            # in the results (so we avoid clobbering any existing admin users)
            request = (
                FluentSearch()
                .where(Asset.GUID.eq(asset_guid))
                .include_on_results(Asset.VIEWER_USERS)
                .page_size(1)
            ).to_request()
            results = tmp.search(request)
            if results.current_page():
                asset = results.current_page()[0]
                existing_viewers = asset.viewer_users or set()
                existing_viewers.add(token_user)
                to_update = asset.trim_to_required()
                to_update.viewer_users = existing_viewers
                response = tmp.save(to_update)
            else:
                AtlanClient.set_default_client(existing_client)
                raise ErrorCode.ASSET_NOT_FOUND_BY_GUID.exception_with_parameters(
                    asset_guid
                )
            AtlanClient.set_default_client(existing_client)
            return response
        return None

    def get_api_tokens(
        self,
        limit: Optional[int] = None,
        post_filter: Optional[str] = None,
        sort: Optional[str] = None,
        count: bool = True,
        offset: int = 0,
    ) -> ApiTokenResponse:
        """
        Retrieves a list of API tokens defined in Atlan.

        :param limit: maximum number of results to be returned
        :param post_filter: which API tokens to retrieve
        :param sort: property by which to sort the results
        :param count: whether to return the total number of records (True) or not (False)
        :param offset: starting point for results to return, for paging
        :returns: a list of API tokens that match the provided criteria
        :raises AtlanError: on any API communication issue
        """
        query_params: dict[str, str] = {
            "count": str(count),
            "offset": str(offset),
        }
        if limit is not None:
            query_params["limit"] = str(limit)
        if post_filter is not None:
            query_params["filter"] = post_filter
        if sort is not None:
            query_params["sort"] = sort
        raw_json = self._client._call_api(
            GET_API_TOKENS.format_path_with_params(), query_params
        )
        return ApiTokenResponse(**raw_json)

    def get_api_token_by_name(self, display_name: str) -> Optional[ApiToken]:
        """
        Retrieves the API token with a name that exactly matches the provided string.

        :param display_name: name (as it appears in the UI) by which to retrieve the API token
        :returns: the API token whose name (in the UI) matches the provided string, or None if there is none
        """
        if response := self.get_api_tokens(
            offset=0,
            limit=5,
            post_filter='{"displayName":"' + display_name + '"}',
        ):
            if response.records and len(response.records) >= 1:
                return response.records[0]
        return None

    def get_api_token_by_id(self, client_id: str) -> Optional[ApiToken]:
        """
        Retrieves the API token with a client ID that exactly matches the provided string.

        :param client_id: unique client identifier by which to retrieve the API token
        :returns: the API token whose clientId matches the provided string, or None if there is none
        """
        if client_id and client_id.startswith(SERVICE_ACCOUNT_):
            client_id = client_id[len(SERVICE_ACCOUNT_) :]  # noqa: E203
        if response := self.get_api_tokens(
            offset=0,
            limit=5,
            post_filter='{"clientId":"' + client_id + '"}',
        ):
            if response.records and len(response.records) >= 1:
                return response.records[0]
        return None

    def create_api_token(
        self,
        display_name: str,
        description: str = "",
        personas: Optional[set[str]] = None,
        validity_seconds: int = -1,
    ) -> ApiToken:
        """
        Create a new API token with the provided settings.

        :param display_name: human-readable name for the API token
        :param description: optional explanation of the API token
        :param personas: qualified_names of personas that should  be linked to the token
        :param validity_seconds: time in seconds after which the token should expire (negative numbers are treated as
                                 infinite)
        :returns: the created API token
        :raises AtlanError: on any API communication issue
        """
        request = ApiTokenRequest(
            display_name=display_name,
            description=description,
            persona_qualified_names=personas or set(),
            validity_seconds=validity_seconds,
        )
        raw_json = self._client._call_api(UPSERT_API_TOKEN, request_obj=request)
        return ApiToken(**raw_json)

    def update_api_token(
        self,
        guid: str,
        display_name: str,
        description: str = "",
        personas: Optional[set[str]] = None,
    ) -> ApiToken:
        """
        Update an existing API token with the provided settings.

        :param guid: unique identifier (GUID) of the API token
        :param display_name: human-readable name for the API token
        :param description: optional explanation of the API token
        :param personas: qualified_names of personas that should  be linked to the token, note that you MUST
                         provide the complete list on any update (any not included in the list will be removed,
                         so if you do not specify any personas then ALL personas will be unlinked from the API token)
        :returns: the created API token
        :raises AtlanError: on any API communication issue
        """
        request = ApiTokenRequest(
            display_name=display_name,
            description=description,
            persona_qualified_names=personas or set(),
        )
        raw_json = self._client._call_api(
            UPSERT_API_TOKEN.format_path_with_params(guid), request_obj=request
        )
        return ApiToken(**raw_json)

    def purge_api_token(self, guid: str) -> None:
        """
        Delete (purge) the specified API token.

        :param guid: unique identifier (GUID) of the API token to delete
        :raises AtlanError: on any API communication issue
        """
        self._client._call_api(DELETE_API_TOKEN.format_path_with_params(guid))
